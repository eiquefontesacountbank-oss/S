# ULTIMAX V2 — Android demo

Este pacote é um **projeto-fonte**, não um APK pronto ou versão aprovada pela Play Store.

## Segurança e dados
- A lista real de 146 funcionários foi **retirada desta compilação de demonstração** para evitar distribuição de dados pessoais em APK público.
- As telas e os fluxos de presença, DSR, dashboard e diaristas foram mantidos no código.
- O app usa `localStorage`, sem login real, sem servidor, sem sincronização e sem criptografia específica dos registros. **Não inserir dados reais de funcionários nesta versão**.
- Há restrições básicas de WebView, bloqueio de capturas de tela e backup Android desativado. Isso não substitui autenticação e proteção de dados.
- Algumas funções HTML podem exigir recursos externos; devem ser auditadas antes do lançamento.

## Compilar pelo GitHub (celular)
1. Crie um repositório **privado** no GitHub e envie o conteúdo desta pasta para a raiz do repositório.
2. Abra **Actions** → **Android Debug APK** → **Run workflow**.
3. Após o workflow terminar, baixe o artifact `ULTIMAX-V2-debug-apk` e extraia o APK para teste.
4. Se o build falhar, consulte os logs do GitHub Actions. O projeto não foi compilado neste ambiente.

## Para produção
Implementar autenticação e controle de acesso no backend, banco de dados e sincronização, políticas LGPD, política de privacidade, testes e pacote AAB assinado. Não colocar credenciais nem base real de funcionários no código do aplicativo.
